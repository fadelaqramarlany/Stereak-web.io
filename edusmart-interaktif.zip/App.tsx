
import React, { useState, useEffect, useCallback } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import SubjectPage from './pages/SubjectPage';
import QuizPage from './pages/QuizPage';
import { ThemeProvider } from './contexts/ThemeContext';

const App: React.FC = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(false);

    const toggleSidebar = useCallback(() => {
        setSidebarOpen(prev => !prev);
    }, []);

    return (
        <ThemeProvider>
            <HashRouter>
                <div className="flex h-screen bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
                    <Sidebar isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
                    <div className="flex-1 flex flex-col overflow-hidden">
                        <Header toggleSidebar={toggleSidebar} />
                        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 dark:bg-gray-900">
                            <div className="container mx-auto px-6 py-8">
                                <Routes>
                                    <Route path="/" element={<HomePage />} />
                                    <Route path="/subject/:subjectId" element={<SubjectPage />} />
                                    <Route path="/quiz/:subjectId/:topicId" element={<QuizPage />} />
                                </Routes>
                            </div>
                        </main>
                    </div>
                </div>
            </HashRouter>
        </ThemeProvider>
    );
};

export default App;
