
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { generateQuiz } from '../services/geminiService';
import { SUBJECTS } from '../constants';
import type { QuizQuestion } from '../types';

type QuizStatus = 'loading' | 'active' | 'finished' | 'error';

const Loader: React.FC = () => (
    <div className="flex flex-col items-center justify-center text-center p-8">
        <svg className="animate-spin h-12 w-12 text-primary mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <h2 className="text-xl font-semibold text-gray-700 dark:text-gray-300">AI sedang menyiapkan kuis...</h2>
        <p className="text-gray-500 dark:text-gray-400">Mohon tunggu sebentar!</p>
    </div>
);

const QuizResults: React.FC<{ score: number; total: number; onRetry: () => void; onBack: () => void }> = ({ score, total, onRetry, onBack }) => (
    <div className="text-center p-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg animate-fade-in">
        <h2 className="text-3xl font-bold text-primary-dark dark:text-primary-light mb-4">Kuis Selesai!</h2>
        <p className="text-5xl font-bold mb-4">{Math.round((score / total) * 100)}<span className="text-2xl">%</span></p>
        <p className="text-xl text-gray-600 dark:text-gray-300 mb-6">Skor Anda: <span className="font-semibold">{score}</span> dari <span className="font-semibold">{total}</span> pertanyaan benar.</p>
        <div className="flex justify-center gap-4">
            <button onClick={onBack} className="px-6 py-2 bg-gray-300 dark:bg-gray-600 text-gray-800 dark:text-gray-200 rounded-lg hover:bg-gray-400 dark:hover:bg-gray-500 transition-colors">
                Kembali
            </button>
            <button onClick={onRetry} className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-primary-light transition-colors">
                Coba Lagi
            </button>
        </div>
    </div>
);

const QuizPage: React.FC = () => {
    const { subjectId, topicId } = useParams<{ subjectId: string, topicId: string }>();
    const navigate = useNavigate();

    const [questions, setQuestions] = useState<QuizQuestion[]>([]);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [score, setScore] = useState(0);
    const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
    const [isAnswered, setIsAnswered] = useState(false);
    const [status, setStatus] = useState<QuizStatus>('loading');
    const [error, setError] = useState<string | null>(null);

    const subject = SUBJECTS.find(s => s.id === subjectId);
    const topic = subject?.topics.find(t => t.id === topicId);

    const loadQuiz = useCallback(async () => {
        if (!subject || !topic) {
            setStatus('error');
            setError("Mata pelajaran atau topik tidak valid.");
            return;
        }
        setStatus('loading');
        setIsAnswered(false);
        setSelectedAnswer(null);
        setCurrentQuestionIndex(0);
        setScore(0);
        try {
            const quizQuestions = await generateQuiz(subject.name, topic.name);
            if(quizQuestions.length > 0) {
              setQuestions(quizQuestions);
              setStatus('active');
            } else {
              throw new Error("AI tidak dapat membuat pertanyaan kuis saat ini.");
            }
        } catch (err: any) {
            setStatus('error');
            setError(err.message || "Gagal memuat kuis.");
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [subject?.name, topic?.name]);

    useEffect(() => {
        loadQuiz();
    }, [loadQuiz]);

    const handleAnswerSelect = (answer: string) => {
        if (isAnswered) return;
        setSelectedAnswer(answer);
        setIsAnswered(true);
        if (answer === questions[currentQuestionIndex].correctAnswer) {
            setScore(prev => prev + 1);
        }
    };

    const handleNextQuestion = () => {
        if (currentQuestionIndex < questions.length - 1) {
            setCurrentQuestionIndex(prev => prev + 1);
            setIsAnswered(false);
            setSelectedAnswer(null);
        } else {
            setStatus('finished');
        }
    };

    const handleGoBack = () => {
        navigate(`/subject/${subjectId}`);
    };

    if (status === 'loading') return <Loader />;
    if (status === 'error') return (
        <div className="text-center p-8 bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-300 rounded-lg">
            <h2 className="text-2xl font-bold mb-2">Terjadi Kesalahan</h2>
            <p>{error}</p>
            <button onClick={loadQuiz} className="mt-4 px-6 py-2 bg-primary text-white rounded-lg hover:bg-primary-light transition-colors">
                Coba Muat Ulang
            </button>
        </div>
    );
    if (status === 'finished') return <QuizResults score={score} total={questions.length} onRetry={loadQuiz} onBack={handleGoBack}/>;

    const currentQuestion = questions[currentQuestionIndex];
    
    return (
        <div className="max-w-4xl mx-auto">
            <div className="bg-white dark:bg-gray-800 p-8 rounded-xl shadow-2xl animate-slide-in-up">
                <div className="mb-6">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Pertanyaan {currentQuestionIndex + 1} dari {questions.length}</p>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mt-2">
                        <div className="bg-secondary h-2.5 rounded-full transition-all duration-500" style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}></div>
                    </div>
                </div>

                <h2 className="text-2xl md:text-3xl font-bold text-gray-800 dark:text-white mb-8">{currentQuestion.question}</h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {currentQuestion.options.map((option, index) => {
                        const isCorrect = option === currentQuestion.correctAnswer;
                        const isSelected = option === selectedAnswer;
                        let buttonClass = 'bg-white dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 border-2 border-gray-300 dark:border-gray-500';

                        if (isAnswered) {
                            if (isCorrect) {
                                buttonClass = 'bg-green-100 dark:bg-green-900/30 border-green-500 text-green-700 dark:text-green-300';
                            } else if (isSelected) {
                                buttonClass = 'bg-red-100 dark:bg-red-900/30 border-red-500 text-red-700 dark:text-red-300';
                            } else {
                                buttonClass = 'bg-gray-100 dark:bg-gray-700 opacity-60';
                            }
                        }

                        return (
                            <button
                                key={index}
                                onClick={() => handleAnswerSelect(option)}
                                disabled={isAnswered}
                                className={`p-4 rounded-lg text-left w-full transition-all duration-300 text-gray-700 dark:text-gray-200 font-medium text-lg ${buttonClass}`}
                            >
                                {option}
                            </button>
                        );
                    })}
                </div>
                
                {isAnswered && (
                    <div className="mt-6 p-4 rounded-lg bg-yellow-50 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-200 animate-fade-in">
                        <h4 className="font-bold">Penjelasan:</h4>
                        <p>{currentQuestion.explanation}</p>
                    </div>
                )}


                <div className="mt-8 text-right">
                    {isAnswered && (
                        <button
                            onClick={handleNextQuestion}
                            className="px-8 py-3 bg-primary text-white font-bold rounded-lg hover:bg-primary-light transition-colors shadow-lg transform hover:scale-105"
                        >
                            {currentQuestionIndex < questions.length - 1 ? 'Lanjut' : 'Lihat Hasil'}
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default QuizPage;
