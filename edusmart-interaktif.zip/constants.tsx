
import React from 'react';
import type { Subject } from './types';

// Icon Components
const BookIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20v2H6.5A2.5 2.5 0 0 1 4 19.5z"/><path d="M4 7h16v10H4z"/></svg>
);
const GlobeIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>
);
const BallIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15.5 15.5-3-3"/><path d="m8.5 8.5 3 3"/><path d="m15.5 8.5-3 3"/><path d="m8.5 15.5 3-3"/></svg>
);
const MosqueIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 13h4l3 7 4-7 3 7h4"/><path d="M12 2v2"/><path d="M12 10v2"/><path d="m2 18 1.8-4.5h16.4L22 18"/><path d="M8 10V8c0-2.2 1.8-4 4-4s4 1.8 4 4v2"/></svg>
);
const PaintBrushIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 15v4c0 1.1.9 2 2 2h4"/><path d="M15 3v4c0 1.1.9 2 2 2h4"/><path d="M12 12a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg>
);
const ShieldIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
);

export const SUBJECTS: Subject[] = [
  { id: 'b-indonesia', name: 'Bahasa Indonesia', icon: BookIcon, color: 'bg-red-500', topics: [
    { id: 'puisi', name: 'Puisi', description: 'Mempelajari bentuk dan unsur-unsur puisi.' },
    { id: 'cerpen', name: 'Cerita Pendek', description: 'Mengidentifikasi struktur dan kaidah kebahasaan cerpen.' },
  ]},
  { id: 'b-inggris', name: 'Bahasa Inggris', icon: GlobeIcon, color: 'bg-blue-500', topics: [
    { id: 'tenses', name: 'Tenses', description: 'Memahami penggunaan berbagai bentuk waktu.' },
    { id: 'vocabulary', name: 'Vocabulary', description: 'Memperkaya kosakata sehari-hari.' },
  ]},
  { id: 'pjok', name: 'PJOK', icon: BallIcon, color: 'bg-green-500', topics: [
    { id: 'sepak-bola', name: 'Sepak Bola', description: 'Teknik dasar dan peraturan permainan sepak bola.' },
    { id: 'atletik', name: 'Atletik', description: 'Mengenal cabang-cabang olahraga atletik.' },
  ]},
  { id: 'hadits', name: 'Hadits', icon: MosqueIcon, color: 'bg-emerald-500', topics: [
    { id: 'hadits-kebersihan', name: 'Hadits Kebersihan', description: 'Pentingnya kebersihan dalam Islam.' },
    { id: 'hadits-niat', name: 'Hadits Niat', description: 'Memahami makna dan pentingnya niat.' },
  ]},
  { id: 'aqidah-akhlak', name: 'Aqidah Akhlak', icon: MosqueIcon, color: 'bg-teal-500', topics: [
    { id: 'sifat-allah', name: 'Sifat Wajib Allah', description: 'Mengenal 20 sifat wajib bagi Allah.' },
    { id: 'akhlak-terpuji', name: 'Akhlak Terpuji', description: 'Contoh dan penerapan akhlak terpuji.' },
  ]},
  { id: 'seni', name: 'Seni', icon: PaintBrushIcon, color: 'bg-purple-500', topics: [
    { id: 'seni-rupa', name: 'Seni Rupa', description: 'Unsur-unsur dan prinsip seni rupa.' },
    { id: 'seni-musik', name: 'Seni Musik', description: 'Mengenal alat musik tradisional dan modern.' },
  ]},
  { id: 'kmdh', name: 'Kemuhammadiyahan', icon: MosqueIcon, color: 'bg-indigo-500', topics: [
    { id: 'sejarah-kmdh', name: 'Sejarah Muhammadiyah', description: 'Latar belakang berdirinya Muhammadiyah.' },
    { id: 'tokoh-kmdh', name: 'Tokoh Muhammadiyah', description: 'Mengenal tokoh-tokoh penting Muhammadiyah.' },
  ]},
  { id: 'fiqih', name: 'Fiqih', icon: MosqueIcon, color: 'bg-cyan-500', topics: [
    { id: 'thaharah', name: 'Thaharah', description: 'Tata cara bersuci dari hadas dan najis.' },
    { id: 'shalat', name: 'Shalat', description: 'Syarat, rukun, dan tata cara shalat.' },
  ]},
  { id: 'pkn', name: 'PKN', icon: ShieldIcon, color: 'bg-yellow-500', topics: [
    { id: 'pancasila', name: 'Pancasila', description: 'Butir-butir dan makna sila Pancasila.' },
    { id: 'uud-1945', name: 'UUD 1945', description: 'Struktur dan isi pokok UUD 1945.' },
  ]},
  { id: 'b-arab', name: 'Bahasa Arab', icon: BookIcon, color: 'bg-lime-500', topics: [
    { id: 'mufradat', name: 'Mufradat (Kosakata)', description: 'Kosakata tentang sekolah dan keluarga.' },
    { id: 'dhamir', name: 'Dhamir (Kata Ganti)', description: 'Penggunaan kata ganti dalam kalimat.' },
  ]},
  { id: 'arab-melayu', name: 'Arab Melayu', icon: BookIcon, color: 'bg-orange-500', topics: [
    { id: 'huruf', name: 'Pengenalan Huruf', description: 'Mengenal dan menulis huruf Arab Melayu.' },
    { id: 'sambung', name: 'Menyambung Huruf', description: 'Aturan menyambung huruf Arab Melayu.' },
  ]},
];
