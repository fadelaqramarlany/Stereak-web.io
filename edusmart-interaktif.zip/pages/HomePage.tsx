
import React from 'react';
import { Link } from 'react-router-dom';
import { SUBJECTS } from '../constants';

const HomePage: React.FC = () => {
    return (
        <div className="animate-fade-in">
            <div className="text-center p-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg mb-8">
                <h1 className="text-4xl font-bold text-primary-dark dark:text-primary-light mb-2">Selamat Datang di EduSmart!</h1>
                <p className="text-lg text-gray-600 dark:text-gray-300">Platform belajar interaktif untuk masa depan cerah. Pilih mata pelajaran di bawah untuk memulai petualangan belajarmu!</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {SUBJECTS.map((subject) => (
                    <Link
                        key={subject.id}
                        to={`/subject/${subject.id}`}
                        className="transform hover:scale-105 transition-transform duration-300"
                    >
                        <div className={`p-6 rounded-xl shadow-md flex flex-col items-center justify-center h-48 ${subject.color}`}>
                            <subject.icon className="w-16 h-16 text-white mb-3" />
                            <h2 className="text-xl font-bold text-white text-center">{subject.name}</h2>
                        </div>
                    </Link>
                ))}
            </div>
        </div>
    );
};

export default HomePage;
