
import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { SUBJECTS } from '../constants';

const ArrowLeftIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>
);

const BookOpenIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
);

const GamepadIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="6" x2="10" y1="12" y2="12"/><line x1="8" x2="8" y1="10" y2="14"/><rect width="20" height="12" x="2" y="6" rx="2"/><path d="M17 11h.01"/><path d="M17 14h.01"/></svg>
);

const SubjectPage: React.FC = () => {
    const { subjectId } = useParams<{ subjectId: string }>();
    const navigate = useNavigate();
    const subject = SUBJECTS.find(s => s.id === subjectId);

    if (!subject) {
        return <div className="text-center text-red-500">Mata pelajaran tidak ditemukan.</div>;
    }

    return (
        <div className="animate-fade-in">
            <button
                onClick={() => navigate('/')}
                className="flex items-center gap-2 mb-6 text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-primary-light transition-colors"
            >
                <ArrowLeftIcon />
                Kembali ke Beranda
            </button>
            <div className={`p-8 rounded-xl shadow-lg mb-8 flex items-center gap-6 ${subject.color}`}>
                <subject.icon className="w-20 h-20 text-white" />
                <div>
                    <h1 className="text-4xl font-bold text-white">{subject.name}</h1>
                    <p className="text-lg text-white/90">Pilih topik untuk mulai belajar dan berlatih.</p>
                </div>
            </div>

            <div className="space-y-4">
                {subject.topics.map(topic => (
                    <div key={topic.id} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md animate-slide-in-up flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div>
                            <h2 className="text-2xl font-semibold text-gray-800 dark:text-white">{topic.name}</h2>
                            <p className="text-gray-500 dark:text-gray-400 mt-1">{topic.description}</p>
                        </div>
                        <div className="flex items-center gap-4 mt-4 md:mt-0 flex-shrink-0">
                            <button className="flex items-center gap-2 px-4 py-2 bg-secondary text-white rounded-lg hover:bg-green-600 transition-colors disabled:bg-gray-400" disabled>
                                <BookOpenIcon />
                                <span>Baca Materi</span>
                            </button>
                            <Link
                                to={`/quiz/${subject.id}/${topic.id}`}
                                className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-light transition-colors"
                            >
                                <GamepadIcon />
                                <span>Mulai Kuis</span>
                            </Link>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default SubjectPage;
