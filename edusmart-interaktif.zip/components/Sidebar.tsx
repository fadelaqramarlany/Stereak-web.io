
import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { SUBJECTS } from '../constants';

interface SidebarProps {
    isOpen: boolean;
    toggleSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, toggleSidebar }) => {
    const location = useLocation();

    return (
        <>
            <div className={`fixed inset-0 z-20 bg-black opacity-50 transition-opacity lg:hidden ${isOpen ? 'block' : 'hidden'}`} onClick={toggleSidebar}></div>
            <div className={`fixed inset-y-0 left-0 z-30 w-64 transform bg-white dark:bg-gray-800 shadow-lg transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                <div className="flex items-center justify-center mt-8">
                    <div className="flex items-center">
                        <span className="text-gray-800 dark:text-white text-2xl font-semibold">Mata Pelajaran</span>
                    </div>
                </div>

                <nav className="mt-10 px-2">
                    {SUBJECTS.map((subject) => (
                        <NavLink
                            key={subject.id}
                            to={`/subject/${subject.id}`}
                            onClick={toggleSidebar}
                            className={({ isActive }) =>
                                `flex items-center px-4 py-3 my-1 rounded-lg transition-colors duration-200 ${
                                    isActive || location.pathname.includes(`/subject/${subject.id}`)
                                        ? `${subject.color} text-white`
                                        : 'text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                                }`
                            }
                        >
                            <subject.icon className="h-6 w-6" />
                            <span className="mx-4 font-medium">{subject.name}</span>
                        </NavLink>
                    ))}
                </nav>
            </div>
        </>
    );
};

export default Sidebar;
