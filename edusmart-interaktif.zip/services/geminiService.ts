
import { GoogleGenAI, Type } from "@google/genai";
import type { QuizQuestion } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This is a fallback for development. In a real environment, the key should be set.
  console.warn("API_KEY is not set in environment variables.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const quizQuestionSchema = {
    type: Type.OBJECT,
    properties: {
        question: { type: Type.STRING, description: 'Pertanyaan kuis yang jelas dan ringkas.' },
        options: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'Array berisi 4 pilihan jawaban, salah satunya benar.'
        },
        correctAnswer: { type: Type.STRING, description: 'Jawaban yang benar dari pilihan yang ada.' },
        explanation: { type: Type.STRING, description: 'Penjelasan singkat mengapa jawaban tersebut benar.' }
    },
    required: ['question', 'options', 'correctAnswer', 'explanation']
};

export const generateQuiz = async (subject: string, topic: string): Promise<QuizQuestion[]> => {
    const prompt = `
        Anda adalah seorang ahli pembuat konten pendidikan untuk siswa SD hingga SMP di Indonesia.
        Buat 5 pertanyaan kuis pilihan ganda yang menarik dan mendidik tentang topik "${topic}" dari mata pelajaran "${subject}".
        Pastikan setiap pertanyaan memiliki 4 pilihan jawaban dan satu jawaban yang benar.
        Sertakan juga penjelasan singkat untuk setiap jawaban yang benar.
        Tingkat kesulitan harus sesuai untuk anak usia 8-14 tahun.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: quizQuestionSchema
                },
                temperature: 0.7,
            },
        });
        
        const jsonText = response.text.trim();
        const quizData = JSON.parse(jsonText);
        
        // Validate the structure
        if (Array.isArray(quizData) && quizData.every(q => q.question && q.options && q.correctAnswer)) {
            return quizData as QuizQuestion[];
        } else {
            console.error("Invalid quiz data structure from API:", quizData);
            throw new Error("Gagal memformat data kuis dari AI.");
        }

    } catch (error) {
        console.error("Error generating quiz:", error);
        throw new Error("Gagal menghasilkan kuis. Silakan coba lagi.");
    }
};
